import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'providers/auth_provider.dart';
import 'providers/produce_provider.dart';
import 'providers/order_provider.dart';
import 'providers/booking_provider.dart';
import 'screens/splash_screen.dart';
import 'utils/constants.dart';
import 'utils/theme.dart';

/// Your Paystack PUBLIC test key. Get this from your Paystack dashboard
/// under Settings > API Keys & Webhooks. Never put your SECRET key here —
/// that belongs on a server that verifies payments, not in the app.
const String paystackPublicKey = "pk_test_REPLACE_WITH_YOUR_PUBLIC_KEY";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  final orderProvider = OrderProvider();
  await orderProvider.paystackService.initialize(paystackPublicKey);

  runApp(SiloLinkApp(orderProvider: orderProvider));
}

class SiloLinkApp extends StatelessWidget {
  final OrderProvider orderProvider;
  const SiloLinkApp({super.key, required this.orderProvider});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => ProduceProvider()),
        ChangeNotifierProvider.value(value: orderProvider),
        ChangeNotifierProvider(create: (_) => BookingProvider()),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const SplashScreen(),
      ),
    );
  }
}
