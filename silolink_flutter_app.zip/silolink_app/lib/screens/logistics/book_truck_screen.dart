import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../providers/booking_provider.dart';
import '../../services/location_service.dart';
import '../../services/firestore_service.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/big_button.dart';
import 'find_trucks_screen.dart';

enum _SettingMode { pickup, dropoff }

class BookTruckScreen extends StatefulWidget {
  const BookTruckScreen({super.key});

  @override
  State<BookTruckScreen> createState() => _BookTruckScreenState();
}

class _BookTruckScreenState extends State<BookTruckScreen> {
  LatLng? _pickup;
  LatLng? _dropoff;
  _SettingMode _mode = _SettingMode.pickup;
  LatLng _center = const LatLng(AppConstants.defaultLat, AppConstants.defaultLng);
  late final LocationService _locationService;

  @override
  void initState() {
    super.initState();
    _locationService = LocationService(FirestoreService());
    _centerOnUser();
  }

  Future<void> _centerOnUser() async {
    final pos = await _locationService.getCurrentPosition();
    if (pos != null && mounted) {
      setState(() {
        _center = LatLng(pos.latitude, pos.longitude);
        _pickup = _center;
      });
    }
  }

  void _onTap(LatLng point) {
    setState(() {
      if (_mode == _SettingMode.pickup) {
        _pickup = point;
        _mode = _SettingMode.dropoff;
      } else {
        _dropoff = point;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Book a Truck")),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: AppTheme.primaryGreen.withOpacity(0.08),
            padding: const EdgeInsets.all(12),
            child: Text(
              _mode == _SettingMode.pickup
                  ? "Tap the map to set your PICKUP location"
                  : "Now tap the map to set your DROP-OFF location",
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.primaryGreen),
            ),
          ),
          Expanded(
            child: FlutterMap(
              options: MapOptions(
                initialCenter: _center,
                initialZoom: 12,
                onTap: (_, point) => _onTap(point),
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.silolink.app',
                ),
                MarkerLayer(markers: [
                  if (_pickup != null)
                    Marker(point: _pickup!, width: 42, height: 42, child: const Icon(Icons.trip_origin, color: AppTheme.primaryGreen, size: 32)),
                  if (_dropoff != null)
                    Marker(point: _dropoff!, width: 42, height: 42, child: const Icon(Icons.flag, color: AppTheme.dangerRed, size: 32)),
                ]),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => setState(() {
                          _pickup = null;
                          _dropoff = null;
                          _mode = _SettingMode.pickup;
                        }),
                        child: const Text("Reset Pins"),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                BigButton(
                  label: "Confirm Locations",
                  icon: Icons.arrow_forward,
                  onPressed: (_pickup != null && _dropoff != null)
                      ? () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => FindTrucksScreen(pickup: _pickup!, dropoff: _dropoff!),
                            ),
                          );
                        }
                      : null,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
