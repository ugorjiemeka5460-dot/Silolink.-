import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../utils/theme.dart';
import '../../widgets/big_button.dart';

class FindTrucksScreen extends StatefulWidget {
  final LatLng pickup;
  final LatLng dropoff;
  const FindTrucksScreen({super.key, required this.pickup, required this.dropoff});

  @override
  State<FindTrucksScreen> createState() => _FindTrucksScreenState();
}

class _FindTrucksScreenState extends State<FindTrucksScreen> {
  String? _selected;
  bool _booking = false;

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final bookingProvider = context.read<BookingProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    final distance = bookingProvider.distanceKm(
      widget.pickup.latitude, widget.pickup.longitude,
      widget.dropoff.latitude, widget.dropoff.longitude,
    );

    final options = [
      {'size': 'Small', 'desc': 'Pickup van · up to 1 tonne'},
      {'size': 'Medium', 'desc': 'Box truck · up to 3 tonnes'},
      {'size': 'Large', 'desc': 'Flatbed truck · up to 8 tonnes'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Choose a Truck")),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text("Trip distance: ${distance.toStringAsFixed(1)} km", style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: options.map((opt) {
                  final size = opt['size']!;
                  final price = bookingProvider.quoteFor(size, distance);
                  final selected = _selected == size;
                  return Card(
                    color: selected ? AppTheme.primaryGreen.withOpacity(0.08) : null,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: selected ? AppTheme.primaryGreen : Colors.transparent, width: 1.5),
                    ),
                    child: ListTile(
                      onTap: () => setState(() => _selected = size),
                      leading: const Icon(Icons.local_shipping, color: AppTheme.primaryGreen, size: 32),
                      title: Text(size, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(opt['desc']!),
                      trailing: Text(currency.format(price), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: BigButton(
                label: "Book This Truck",
                icon: Icons.check_circle_outline,
                loading: _booking,
                onPressed: _selected == null
                    ? null
                    : () async {
                        setState(() => _booking = true);
                        final price = bookingProvider.quoteFor(_selected!, distance);
                        final booking = BookingModel(
                          id: '',
                          requesterId: user.uid,
                          requesterName: user.name,
                          truckSize: _selected!,
                          pickupLat: widget.pickup.latitude,
                          pickupLng: widget.pickup.longitude,
                          pickupAddress: "${widget.pickup.latitude.toStringAsFixed(4)}, ${widget.pickup.longitude.toStringAsFixed(4)}",
                          dropoffLat: widget.dropoff.latitude,
                          dropoffLng: widget.dropoff.longitude,
                          dropoffAddress: "${widget.dropoff.latitude.toStringAsFixed(4)}, ${widget.dropoff.longitude.toStringAsFixed(4)}",
                          distanceKm: distance,
                          price: price,
                        );
                        final id = await bookingProvider.createBooking(booking);
                        setState(() => _booking = false);
                        if (id != null && context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Truck booked! We're notifying nearby drivers.")),
                          );
                          Navigator.of(context).popUntil((route) => route.isFirst);
                        }
                      },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
