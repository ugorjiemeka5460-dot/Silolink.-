import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../widgets/status_pill.dart';
import '../../utils/theme.dart';

/// Farmer/buyer-facing screen: watches the assigned driver's live
/// position (updated every ~10s by the driver's app) alongside the
/// pickup and drop-off pins, so they know exactly where their produce is.
class LiveTrackingScreen extends StatelessWidget {
  final String bookingId;
  const LiveTrackingScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    final bookingProvider = context.read<BookingProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text("Track Delivery")),
      body: StreamBuilder<BookingModel?>(
        stream: bookingProvider.watchBooking(bookingId),
        builder: (context, bookingSnap) {
          if (!bookingSnap.hasData || bookingSnap.data == null) {
            return const Center(child: CircularProgressIndicator());
          }
          final booking = bookingSnap.data!;
          final pickup = LatLng(booking.pickupLat, booking.pickupLng);
          final dropoff = LatLng(booking.dropoffLat, booking.dropoffLng);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        booking.driverName != null ? "Driver: ${booking.driverName}" : "Waiting for a driver...",
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    StatusPill.forBookingStatus(booking.status.name),
                  ],
                ),
              ),
              Expanded(
                child: booking.driverId == null
                    ? FlutterMap(
                        options: MapOptions(initialCenter: pickup, initialZoom: 11),
                        children: [
                          TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.silolink.app'),
                          MarkerLayer(markers: [
                            Marker(point: pickup, width: 42, height: 42, child: const Icon(Icons.trip_origin, color: AppTheme.primaryGreen, size: 32)),
                            Marker(point: dropoff, width: 42, height: 42, child: const Icon(Icons.flag, color: AppTheme.dangerRed, size: 32)),
                          ]),
                        ],
                      )
                    : _DriverLiveMap(driverId: booking.driverId!, pickup: pickup, dropoff: dropoff),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _DriverLiveMap extends StatelessWidget {
  final String driverId;
  final LatLng pickup;
  final LatLng dropoff;
  const _DriverLiveMap({required this.driverId, required this.pickup, required this.dropoff});

  @override
  Widget build(BuildContext context) {
    final bookingProvider = context.read<BookingProvider>();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: bookingProvider.driverLocationStream(driverId),
      builder: (context, snap) {
        LatLng? driverPos;
        if (snap.hasData && snap.data!.exists) {
          final data = snap.data!.data()!;
          final lat = (data['lat'] as num?)?.toDouble();
          final lng = (data['lng'] as num?)?.toDouble();
          if (lat != null && lng != null) driverPos = LatLng(lat, lng);
        }

        return FlutterMap(
          options: MapOptions(initialCenter: driverPos ?? pickup, initialZoom: 12),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.silolink.app'),
            MarkerLayer(markers: [
              Marker(point: pickup, width: 42, height: 42, child: const Icon(Icons.trip_origin, color: AppTheme.primaryGreen, size: 32)),
              Marker(point: dropoff, width: 42, height: 42, child: const Icon(Icons.flag, color: AppTheme.dangerRed, size: 32)),
              if (driverPos != null)
                Marker(point: driverPos, width: 46, height: 46, child: const Icon(Icons.local_shipping, color: Colors.black87, size: 34)),
            ]),
          ],
        );
      },
    );
  }
}
