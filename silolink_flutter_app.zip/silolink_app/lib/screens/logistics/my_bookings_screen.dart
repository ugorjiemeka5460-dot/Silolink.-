import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../utils/constants.dart';
import '../../widgets/status_pill.dart';
import 'live_tracking_screen.dart';

/// For farmers and buyers to see the truck bookings they've requested,
/// and tap into live tracking for anything in progress.
class MyBookingsScreen extends StatelessWidget {
  const MyBookingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final bookingProvider = context.read<BookingProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(title: const Text("My Truck Bookings")),
      body: StreamBuilder<List<BookingModel>>(
        stream: bookingProvider.requesterBookings(user.uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final bookings = snap.data!;
          if (bookings.isEmpty) {
            return const Center(child: Text("No truck bookings yet.", style: TextStyle(color: Colors.black54)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: bookings.length,
            itemBuilder: (context, i) {
              final b = bookings[i];
              final trackable = b.status == BookingStatus.accepted || b.status == BookingStatus.inTransit;
              return Card(
                child: ListTile(
                  title: Text("${b.truckSize} truck · ${currency.format(b.price)}"),
                  subtitle: Text("${b.pickupAddress} → ${b.dropoffAddress}"),
                  trailing: StatusPill.forBookingStatus(b.status.name),
                  onTap: trackable
                      ? () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => LiveTrackingScreen(bookingId: b.id)),
                          )
                      : null,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
