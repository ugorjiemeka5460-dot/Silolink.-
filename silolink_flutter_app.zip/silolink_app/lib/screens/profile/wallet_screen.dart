import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/status_pill.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final orderProvider = context.read<OrderProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    // Farmers see money coming IN from paid/delivered orders; buyers see
    // money going OUT on the same order stream, filtered the other way.
    final isFarmer = user.role == UserRole.farmer;
    final stream = isFarmer ? orderProvider.farmerOrders(user.uid) : orderProvider.buyerOrders(user.uid);

    return Scaffold(
      appBar: AppBar(title: const Text("Wallet")),
      body: StreamBuilder<List<OrderModel>>(
        stream: stream,
        builder: (context, snap) {
          final orders = snap.data ?? [];
          final settled = orders.where((o) => o.status == OrderStatus.paid || o.status == OrderStatus.delivered);
          final total = settled.fold<double>(0, (sum, o) => sum + o.totalPrice);

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                color: AppTheme.primaryGreen,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(isFarmer ? "Total Earnings" : "Total Spent", style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 6),
                      Text(currency.format(total), style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text("Transaction History", style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              if (orders.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(child: Text("No transactions yet.", style: TextStyle(color: Colors.black54))),
                )
              else
                ...orders.map((o) => Card(
                      child: ListTile(
                        title: Text("${o.quantity.toStringAsFixed(0)} kg ${o.crop}"),
                        subtitle: Text(isFarmer ? "Buyer: ${o.buyerName}" : "Farmer: ${o.farmerName}"),
                        trailing: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(currency.format(o.totalPrice), style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            StatusPill.forOrderStatus(o.status.name),
                          ],
                        ),
                      ),
                    )),
            ],
          );
        },
      ),
    );
  }
}
