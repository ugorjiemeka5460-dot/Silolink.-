import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/location_service.dart';
import '../../services/firestore_service.dart';
import '../../models/user_model.dart';
import '../../utils/constants.dart';
import '../../widgets/big_button.dart';
import '../auth/role_selection_screen.dart';
import 'wallet_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameController = TextEditingController();
  bool _saving = false;
  late final LocationService _locationService;

  @override
  void initState() {
    super.initState();
    _locationService = LocationService(FirestoreService());
    final user = context.read<AuthProvider>().currentAppUser;
    if (user != null) _nameController.text = user.name;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentAppUser;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final firestoreService = FirestoreService();

    return Scaffold(
      appBar: AppBar(title: const Text("Profile")),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: CircleAvatar(
                radius: 40,
                child: Text(
                  user.name.isNotEmpty ? user.name[0].toUpperCase() : "?",
                  style: const TextStyle(fontSize: 30),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Center(child: Text(user.role.label, style: const TextStyle(color: Colors.black54))),
            const SizedBox(height: 24),
            const Text("Full name", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(controller: _nameController),
            const SizedBox(height: 16),
            const Text("Phone number", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(enabled: false, controller: TextEditingController(text: user.phone)),
            const SizedBox(height: 16),
            if (user.locationName != null) ...[
              const Text("Location on file", style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(user.locationName!, style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 16),
            ],
            BigButton(
              label: "Update Current Location",
              icon: Icons.my_location,
              outlined: true,
              onPressed: () async {
                final pos = await _locationService.getCurrentPosition();
                if (pos != null) {
                  final updated = user.copyWith(
                    lat: pos.latitude,
                    lng: pos.longitude,
                    locationName: "${pos.latitude.toStringAsFixed(4)}, ${pos.longitude.toStringAsFixed(4)}",
                  );
                  await firestoreService.createOrUpdateUser(updated);
                  await auth.refreshProfile();
                }
              },
            ),
            const SizedBox(height: 12),
            BigButton(
              label: "Wallet",
              icon: Icons.account_balance_wallet_outlined,
              outlined: true,
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WalletScreen())),
            ),
            const SizedBox(height: 24),
            BigButton(
              label: "Save Changes",
              icon: Icons.save_outlined,
              loading: _saving,
              onPressed: () async {
                setState(() => _saving = true);
                final updated = user.copyWith(name: _nameController.text.trim());
                await firestoreService.createOrUpdateUser(updated);
                await auth.refreshProfile();
                setState(() => _saving = false);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Profile updated.")));
                }
              },
            ),
            const SizedBox(height: 12),
            BigButton(
              label: "Sign Out",
              icon: Icons.logout,
              color: Colors.black87,
              onPressed: () async {
                await auth.signOut();
                if (context.mounted) {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
                    (route) => false,
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
