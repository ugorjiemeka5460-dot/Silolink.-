import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/produce_model.dart';
import '../../utils/theme.dart';
import '../../widgets/big_button.dart';
import 'payment_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Produce produce;
  const ProductDetailScreen({super.key, required this.produce});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  double _quantity = 1;

  @override
  void initState() {
    super.initState();
    _quantity = widget.produce.quantity >= 10 ? 10 : widget.produce.quantity;
  }

  Future<void> _callFarmer(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone);
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.produce;
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);
    final user = context.watch<AuthProvider>().currentAppUser!;
    final orderProvider = context.read<OrderProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(p.crop)),
      body: SafeArea(
        child: ListView(
          children: [
            SizedBox(
              height: 220,
              width: double.infinity,
              child: p.photoUrl != null
                  ? CachedNetworkImage(imageUrl: p.photoUrl!, fit: BoxFit.cover)
                  : Container(color: const Color(0xFFE8F5E9), child: const Icon(Icons.agriculture, size: 64, color: AppTheme.primaryGreen)),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.crop, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Text("${currency.format(p.pricePerKg)}/kg · ${p.quantity.toStringAsFixed(0)} kg available",
                      style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 16),
                  Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.person)),
                      title: Text(p.farmerName),
                      subtitle: Text(p.locationName),
                      trailing: IconButton(
                        icon: const Icon(Icons.call, color: AppTheme.primaryGreen),
                        onPressed: () => _callFarmer(p.farmerPhone),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text("How many kg do you need?", style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      IconButton.filled(
                        onPressed: () => setState(() => _quantity = (_quantity - 5).clamp(1, p.quantity)),
                        icon: const Icon(Icons.remove),
                      ),
                      Expanded(
                        child: Text("${_quantity.toStringAsFixed(0)} kg", textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                      ),
                      IconButton.filled(
                        onPressed: () => setState(() => _quantity = (_quantity + 5).clamp(1, p.quantity)),
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Total: ${currency.format(_quantity * p.pricePerKg)}",
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.primaryGreen),
                  ),
                  const SizedBox(height: 24),
                  BigButton(
                    label: "Order Now",
                    icon: Icons.shopping_cart_checkout,
                    loading: orderProvider.isProcessing,
                    onPressed: () async {
                      final orderId = await orderProvider.placeOrder(
                        produce: p,
                        buyerId: user.uid,
                        buyerName: user.name,
                        quantity: _quantity,
                      );
                      if (orderId != null && context.mounted) {
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (_) => PaymentScreen(
                              orderId: orderId,
                              produceId: p.id,
                              crop: p.crop,
                              quantity: _quantity,
                              totalPrice: _quantity * p.pricePerKg,
                            ),
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
