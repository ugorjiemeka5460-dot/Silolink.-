import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/big_button.dart';
import 'my_orders_screen.dart';

class PaymentScreen extends StatelessWidget {
  final String orderId;
  final String produceId;
  final String crop;
  final double quantity;
  final double totalPrice;

  const PaymentScreen({
    super.key,
    required this.orderId,
    required this.produceId,
    required this.crop,
    required this.quantity,
    required this.totalPrice,
  });

  @override
  Widget build(BuildContext context) {
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);
    final user = context.watch<AuthProvider>().currentAppUser!;
    final orderProvider = context.watch<OrderProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text("Payment")),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Icon(Icons.receipt_long, size: 56, color: AppTheme.primaryGreen),
              const SizedBox(height: 16),
              Text("Order placed!", style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 6),
              Text(
                "${quantity.toStringAsFixed(0)} kg of $crop",
                style: const TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Text("Amount to pay", style: TextStyle(color: Colors.black54)),
                      const SizedBox(height: 6),
                      Text(currency.format(totalPrice), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
              if (orderProvider.errorMessage != null) ...[
                const SizedBox(height: 12),
                Text(orderProvider.errorMessage!, style: const TextStyle(color: Colors.red)),
              ],
              const Spacer(),
              BigButton(
                label: "Pay with Paystack",
                icon: Icons.lock_outline,
                color: AppTheme.accentYellow,
                textColor: Colors.black,
                loading: orderProvider.isProcessing,
                onPressed: () async {
                  final ok = await orderProvider.payForOrder(
                    orderId: orderId,
                    produceId: produceId,
                    buyerEmail: "${user.phone.replaceAll('+', '')}@silolink.app",
                    totalPrice: totalPrice,
                  );
                  if (context.mounted) {
                    if (ok) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Payment successful!")),
                      );
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const MyOrdersScreen()),
                        (route) => route.isFirst,
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Payment was not completed. Please try again.")),
                      );
                    }
                  }
                },
              ),
              const SizedBox(height: 8),
              const Text(
                "Secured by Paystack. Your card details are never stored by SiloLink.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Colors.black45),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
