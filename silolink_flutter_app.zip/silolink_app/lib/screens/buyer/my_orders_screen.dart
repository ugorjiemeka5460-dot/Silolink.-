import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';
import '../../widgets/status_pill.dart';

class MyOrdersScreen extends StatelessWidget {
  const MyOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final orderProvider = context.read<OrderProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(title: const Text("My Orders")),
      body: StreamBuilder<List<OrderModel>>(
        stream: orderProvider.buyerOrders(user.uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final orders = snap.data!;
          if (orders.isEmpty) {
            return const Center(child: Text("You haven't placed any orders yet.", style: TextStyle(color: Colors.black54)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            itemBuilder: (context, i) {
              final o = orders[i];
              return Card(
                child: ListTile(
                  title: Text("${o.quantity.toStringAsFixed(0)} kg ${o.crop}"),
                  subtitle: Text("From ${o.farmerName} · ${currency.format(o.totalPrice)}"),
                  trailing: StatusPill.forOrderStatus(o.status.name),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
