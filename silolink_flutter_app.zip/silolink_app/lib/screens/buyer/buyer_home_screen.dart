import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/produce_provider.dart';
import '../../models/produce_model.dart';
import '../../widgets/produce_card.dart';
import '../profile/profile_screen.dart';
import '../logistics/book_truck_screen.dart';
import '../logistics/my_bookings_screen.dart';
import 'product_detail_screen.dart';
import 'my_orders_screen.dart';

class BuyerHomeScreen extends StatefulWidget {
  const BuyerHomeScreen({super.key});

  @override
  State<BuyerHomeScreen> createState() => _BuyerHomeScreenState();
}

class _BuyerHomeScreenState extends State<BuyerHomeScreen> {
  final _searchController = TextEditingController();
  String _query = "";
  String _sort = "Newest";

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final produceProvider = context.read<ProduceProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Browse Produce"),
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long_outlined),
            tooltip: "My Orders",
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyOrdersScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.local_shipping_outlined),
            tooltip: "My Truck Bookings",
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyBookingsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BookTruckScreen())),
        icon: const Icon(Icons.local_shipping_outlined),
        label: const Text("Book Truck"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                hintText: "Search crop, e.g. Yam, Maize, Tomatoes",
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text("Sort by:", style: TextStyle(color: Colors.black54, fontSize: 13)),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: _sort,
                  underline: const SizedBox(),
                  items: const [
                    DropdownMenuItem(value: "Newest", child: Text("Newest")),
                    DropdownMenuItem(value: "Price: Low to High", child: Text("Price: Low to High")),
                    DropdownMenuItem(value: "Price: High to Low", child: Text("Price: High to Low")),
                  ],
                  onChanged: (v) => setState(() => _sort = v ?? "Newest"),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Produce>>(
              stream: produceProvider.browseAvailable(cropFilter: _query),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                var items = List<Produce>.from(snap.data!);
                if (_sort == "Price: Low to High") items.sort((a, b) => a.pricePerKg.compareTo(b.pricePerKg));
                if (_sort == "Price: High to Low") items.sort((a, b) => b.pricePerKg.compareTo(a.pricePerKg));

                if (items.isEmpty) {
                  return const Center(child: Text("No produce matches your search.", style: TextStyle(color: Colors.black54)));
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                  itemCount: items.length,
                  itemBuilder: (context, i) => ProduceCard(
                    produce: items[i],
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => ProductDetailScreen(produce: items[i])),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
