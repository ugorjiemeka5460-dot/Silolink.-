import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../utils/constants.dart';
import '../../widgets/status_pill.dart';
import 'track_delivery_screen.dart';

class MyTripsScreen extends StatelessWidget {
  const MyTripsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final bookingProvider = context.read<BookingProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text("My Trips")),
      body: StreamBuilder<List<BookingModel>>(
        stream: bookingProvider.driverTrips(user.uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final trips = snap.data!;
          if (trips.isEmpty) {
            return const Center(child: Text("No trips yet. Accepted bookings show up here.", style: TextStyle(color: Colors.black54)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: trips.length,
            itemBuilder: (context, i) {
              final b = trips[i];
              final active = b.status == BookingStatus.accepted || b.status == BookingStatus.inTransit;
              return Card(
                child: ListTile(
                  title: Text("${b.truckSize} truck · ${b.requesterName}"),
                  subtitle: Text("${b.pickupAddress} → ${b.dropoffAddress}"),
                  trailing: StatusPill.forBookingStatus(b.status.name),
                  onTap: active
                      ? () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => TrackDeliveryScreen(booking: b)),
                          )
                      : null,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
