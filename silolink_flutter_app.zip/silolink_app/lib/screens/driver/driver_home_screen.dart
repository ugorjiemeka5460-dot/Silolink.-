import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../utils/theme.dart';
import '../profile/profile_screen.dart';
import 'my_trips_screen.dart';

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  bool _online = false;

  @override
  void dispose() {
    context.read<BookingProvider>().goOffline();
    super.dispose();
  }

  void _toggleOnline(bool value, String driverId) {
    setState(() => _online = value);
    final booking = context.read<BookingProvider>();
    if (value) {
      booking.goOnline(driverId);
    } else {
      booking.goOffline();
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final bookingProvider = context.read<BookingProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Driver Dashboard"),
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long_outlined),
            tooltip: "My Trips",
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyTripsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: _online ? AppTheme.primaryGreen : Colors.grey.shade400,
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
            child: Row(
              children: [
                Icon(_online ? Icons.check_circle : Icons.pause_circle, color: Colors.white),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _online ? "You're Online — bookings will come in" : "You're Offline",
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
                Switch(
                  value: _online,
                  activeColor: Colors.white,
                  onChanged: (v) => _toggleOnline(v, user.uid),
                ),
              ],
            ),
          ),
          Expanded(
            child: !_online
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text(
                        "Go online to start seeing available truck bookings nearby.",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black54),
                      ),
                    ),
                  )
                : StreamBuilder<List<BookingModel>>(
                    stream: bookingProvider.availableBookings(),
                    builder: (context, snap) {
                      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                      final bookings = snap.data!;
                      if (bookings.isEmpty) {
                        return const Center(child: Text("No bookings available right now.", style: TextStyle(color: Colors.black54)));
                      }
                      return ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: bookings.length,
                        itemBuilder: (context, i) {
                          final b = bookings[i];
                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.local_shipping, color: AppTheme.primaryGreen),
                                      const SizedBox(width: 8),
                                      Text("${b.truckSize} truck", style: const TextStyle(fontWeight: FontWeight.w700)),
                                      const Spacer(),
                                      Text(currency.format(b.price), style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primaryGreen)),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text("Pickup: ${b.pickupAddress}", style: const TextStyle(fontSize: 13)),
                                  Text("Drop-off: ${b.dropoffAddress}", style: const TextStyle(fontSize: 13)),
                                  Text("${b.distanceKm.toStringAsFixed(1)} km · Requested by ${b.requesterName}", style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                  const SizedBox(height: 12),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: OutlinedButton(
                                          onPressed: () {}, // Reject = simply ignore/don't accept.
                                          child: const Text("Ignore"),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () async {
                                            final accepted = await bookingProvider.acceptBooking(b.id, user.uid, user.name);
                                            if (context.mounted) {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(content: Text(accepted ? "Trip accepted!" : "Someone else already took this trip.")),
                                              );
                                            }
                                          },
                                          child: const Text("Accept"),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
