import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../providers/booking_provider.dart';
import '../../models/booking_model.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/big_button.dart';

/// The driver's view of their current trip: pickup/drop-off pins on an
/// OpenStreetMap tile layer, plus controls to move the trip through its
/// states. This screen doesn't push the driver's own location — that
/// happens continuously in the background once they toggle "Online" on
/// the dashboard (see BookingProvider.goOnline).
class TrackDeliveryScreen extends StatelessWidget {
  final BookingModel booking;
  const TrackDeliveryScreen({super.key, required this.booking});

  @override
  Widget build(BuildContext context) {
    final bookingProvider = context.read<BookingProvider>();
    final pickup = LatLng(booking.pickupLat, booking.pickupLng);
    final dropoff = LatLng(booking.dropoffLat, booking.dropoffLng);
    final center = LatLng(
      (booking.pickupLat + booking.dropoffLat) / 2,
      (booking.pickupLng + booking.dropoffLng) / 2,
    );

    return Scaffold(
      appBar: AppBar(title: const Text("Current Trip")),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              options: MapOptions(initialCenter: center, initialZoom: 11),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.silolink.app',
                ),
                MarkerLayer(markers: [
                  Marker(point: pickup, width: 42, height: 42, child: const Icon(Icons.trip_origin, color: AppTheme.primaryGreen, size: 32)),
                  Marker(point: dropoff, width: 42, height: 42, child: const Icon(Icons.flag, color: AppTheme.dangerRed, size: 32)),
                ]),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("${booking.pickupAddress} → ${booking.dropoffAddress}", style: const TextStyle(fontWeight: FontWeight.w700)),
                Text("${booking.distanceKm.toStringAsFixed(1)} km · ${booking.truckSize} truck", style: const TextStyle(color: Colors.black54, fontSize: 13)),
                const SizedBox(height: 16),
                if (booking.status == BookingStatus.accepted)
                  BigButton(
                    label: "Start Trip",
                    icon: Icons.play_arrow,
                    onPressed: () async {
                      await bookingProvider.updateStatus(booking.id, BookingStatus.inTransit);
                      if (context.mounted) Navigator.of(context).pop();
                    },
                  ),
                if (booking.status == BookingStatus.inTransit)
                  BigButton(
                    label: "Mark Delivered",
                    icon: Icons.check_circle_outline,
                    color: AppTheme.primaryGreen,
                    onPressed: () async {
                      await bookingProvider.updateStatus(booking.id, BookingStatus.delivered);
                      if (context.mounted) Navigator.of(context).pop();
                    },
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
