import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/produce_provider.dart';
import '../../services/location_service.dart';
import '../../services/firestore_service.dart';
import '../../widgets/big_button.dart';

class PostProduceScreen extends StatefulWidget {
  const PostProduceScreen({super.key});

  @override
  State<PostProduceScreen> createState() => _PostProduceScreenState();
}

class _PostProduceScreenState extends State<PostProduceScreen> {
  final _cropController = TextEditingController();
  final _quantityController = TextEditingController();
  final _priceController = TextEditingController();
  final _locationController = TextEditingController();
  File? _photo;
  double? _lat;
  double? _lng;
  bool _locating = false;

  final _picker = ImagePicker();
  late final LocationService _locationService;

  @override
  void initState() {
    super.initState();
    _locationService = LocationService(FirestoreService());
  }

  @override
  void dispose() {
    _cropController.dispose();
    _quantityController.dispose();
    _priceController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final picked = await _picker.pickImage(source: ImageSource.camera, imageQuality: 75);
    if (picked != null) setState(() => _photo = File(picked.path));
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _locating = true);
    final pos = await _locationService.getCurrentPosition();
    setState(() {
      _locating = false;
      if (pos != null) {
        _lat = pos.latitude;
        _lng = pos.longitude;
        _locationController.text = "${pos.latitude.toStringAsFixed(4)}, ${pos.longitude.toStringAsFixed(4)}";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final produceProvider = context.watch<ProduceProvider>();
    final user = auth.currentAppUser!;

    return Scaffold(
      appBar: AppBar(title: const Text("Post New Produce")),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GestureDetector(
              onTap: _pickPhoto,
              child: Container(
                height: 160,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFDDDDDD)),
                ),
                child: _photo != null
                    ? ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(_photo!, fit: BoxFit.cover, width: double.infinity))
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.camera_alt_outlined, size: 36, color: Colors.black38),
                          SizedBox(height: 8),
                          Text("Tap to add a photo", style: TextStyle(color: Colors.black45)),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 20),
            const Text("Crop name", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(controller: _cropController, decoration: const InputDecoration(hintText: "e.g. Yam Tubers")),
            const SizedBox(height: 16),
            const Text("Quantity (kg)", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(controller: _quantityController, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: "e.g. 500")),
            const SizedBox(height: 16),
            const Text("Price per kg (₦)", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(controller: _priceController, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: "e.g. 800")),
            const SizedBox(height: 16),
            const Text("Location", style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            TextField(
              controller: _locationController,
              decoration: InputDecoration(
                hintText: "Tap the pin to use your current location",
                suffixIcon: IconButton(
                  icon: _locating
                      ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.my_location),
                  onPressed: _locating ? null : _useCurrentLocation,
                ),
              ),
            ),
            if (produceProvider.errorMessage != null) ...[
              const SizedBox(height: 12),
              Text(produceProvider.errorMessage!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 24),
            BigButton(
              label: "Post Produce",
              icon: Icons.check_circle_outline,
              loading: produceProvider.isSubmitting,
              onPressed: () async {
                final crop = _cropController.text.trim();
                final qty = double.tryParse(_quantityController.text.trim());
                final price = double.tryParse(_priceController.text.trim());
                if (crop.isEmpty || qty == null || price == null) return;

                final ok = await produceProvider.postProduce(
                  farmerId: user.uid,
                  farmerName: user.name,
                  farmerPhone: user.phone,
                  crop: crop,
                  quantity: qty,
                  pricePerKg: price,
                  photo: _photo,
                  lat: _lat,
                  lng: _lng,
                  locationName: _locationController.text.trim().isEmpty ? "Unspecified" : _locationController.text.trim(),
                );
                if (ok && context.mounted) Navigator.of(context).pop();
              },
            ),
          ],
        ),
      ),
    );
  }
}
