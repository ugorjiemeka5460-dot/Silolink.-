import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/produce_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/produce_model.dart';
import '../../models/order_model.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../profile/profile_screen.dart';
import '../logistics/book_truck_screen.dart';
import '../logistics/my_bookings_screen.dart';
import 'post_produce_screen.dart';
import 'find_buyers_screen.dart';

class FarmerHomeScreen extends StatelessWidget {
  const FarmerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentAppUser;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final produceProvider = context.read<ProduceProvider>();
    final orderProvider = context.read<OrderProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(
        title: const Text("My Farm"),
        actions: [
          IconButton(
            icon: const Icon(Icons.local_shipping_outlined),
            tooltip: "My Truck Bookings",
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyBookingsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PostProduceScreen())),
        icon: const Icon(Icons.add),
        label: const Text("Post Produce"),
        backgroundColor: AppTheme.accentYellow,
        foregroundColor: Colors.black,
      ),
      body: RefreshIndicator(
        onRefresh: () async {},
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text("Hello, ${user.name.split(' ').first} 👋", style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            const Text("Here's what's happening on your farm today.", style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 16),

            // Active orders + earnings summary
            StreamBuilder<List<OrderModel>>(
              stream: orderProvider.farmerOrders(user.uid),
              builder: (context, snap) {
                final orders = snap.data ?? [];
                final active = orders.where((o) => o.status != OrderStatus.delivered && o.status != OrderStatus.cancelled).length;
                final earnings = orders.where((o) => o.status == OrderStatus.paid || o.status == OrderStatus.delivered).fold<double>(0, (sum, o) => sum + o.totalPrice);
                return Row(
                  children: [
                    Expanded(child: _StatCard(label: "Active Orders", value: "$active", icon: Icons.local_shipping_outlined)),
                    const SizedBox(width: 12),
                    Expanded(child: _StatCard(label: "Earnings", value: currency.format(earnings), icon: Icons.payments_outlined)),
                  ],
                );
              },
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.people_outline),
                    label: const Text("Find Buyers"),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FindBuyersScreen())),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.local_shipping_outlined),
                    label: const Text("Book Truck"),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BookTruckScreen())),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            Text("My Produce", style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            StreamBuilder<List<Produce>>(
              stream: produceProvider.myProduce(user.uid),
              builder: (context, snap) {
                if (!snap.hasData) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
                final items = snap.data!;
                if (items.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: Text("You haven't posted any produce yet.", style: TextStyle(color: Colors.black54))),
                  );
                }
                return Column(
                  children: items.map((p) => Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: p.status == 'available' ? AppTheme.primaryGreen.withOpacity(0.15) : Colors.black12,
                        child: Icon(Icons.agriculture, color: p.status == 'available' ? AppTheme.primaryGreen : Colors.black45),
                      ),
                      title: Text(p.crop),
                      subtitle: Text("${p.quantity.toStringAsFixed(0)} kg · ${currency.format(p.pricePerKg)}/kg"),
                      trailing: Text(
                        p.status == 'available' ? "Available" : "Sold",
                        style: TextStyle(
                          color: p.status == 'available' ? AppTheme.primaryGreen : Colors.black45,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  )).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: AppTheme.primaryGreen),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}
