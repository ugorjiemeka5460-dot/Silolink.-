import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';
import '../../widgets/status_pill.dart';

/// Shows buyers who have placed a pending order against this farmer's
/// produce — the clearest, most actionable signal of buyer interest we
/// have without building a separate page-view tracking pipeline.
class FindBuyersScreen extends StatelessWidget {
  const FindBuyersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentAppUser!;
    final orderProvider = context.read<OrderProvider>();
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(title: const Text("Find Buyers")),
      body: StreamBuilder<List<OrderModel>>(
        stream: orderProvider.farmerLeads(user.uid),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final leads = snap.data!;
          if (leads.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  "No buyers waiting right now. Interested buyers who order your produce will show up here.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54),
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: leads.length,
            itemBuilder: (context, i) {
              final o = leads[i];
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(o.buyerName),
                  subtitle: Text("Wants ${o.quantity.toStringAsFixed(0)} kg of ${o.crop} · ${currency.format(o.totalPrice)}"),
                  trailing: StatusPill.forOrderStatus(o.status.name),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
