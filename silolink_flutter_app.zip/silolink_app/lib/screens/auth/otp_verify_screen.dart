import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/constants.dart';
import '../../widgets/big_button.dart';
import '../farmer/farmer_home_screen.dart';
import '../buyer/buyer_home_screen.dart';
import '../driver/driver_home_screen.dart';

class OtpVerifyScreen extends StatefulWidget {
  final String name;
  final UserRole role;
  const OtpVerifyScreen({super.key, required this.name, required this.role});

  @override
  State<OtpVerifyScreen> createState() => _OtpVerifyScreenState();
}

class _OtpVerifyScreenState extends State<OtpVerifyScreen> {
  final _codeController = TextEditingController();

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text("Enter the code")),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Enter the 6-digit code we sent by SMS.",
                style: TextStyle(fontSize: 15, color: Colors.black54),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _codeController,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 6,
                style: const TextStyle(fontSize: 26, letterSpacing: 10, fontWeight: FontWeight.w700),
                decoration: const InputDecoration(counterText: ""),
              ),
              if (auth.errorMessage != null) ...[
                const SizedBox(height: 12),
                Text(auth.errorMessage!, style: const TextStyle(color: Colors.red)),
              ],
              const Spacer(),
              BigButton(
                label: "Verify & Continue",
                icon: Icons.check_circle_outline,
                loading: auth.isLoading,
                onPressed: () async {
                  final ok = await auth.verifyOtpAndCreateProfile(
                    smsCode: _codeController.text.trim(),
                    name: widget.name,
                    role: widget.role,
                  );
                  if (ok && context.mounted) {
                    Widget home;
                    switch (widget.role) {
                      case UserRole.farmer:
                        home = const FarmerHomeScreen();
                        break;
                      case UserRole.driver:
                        home = const DriverHomeScreen();
                        break;
                      case UserRole.buyer:
                        home = const BuyerHomeScreen();
                        break;
                    }
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => home),
                      (route) => false,
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
