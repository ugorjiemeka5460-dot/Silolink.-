import 'package:flutter/material.dart';
import '../../utils/constants.dart';
import '../../widgets/role_card.dart';
import 'phone_entry_screen.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24),
              Text("Welcome to ${AppConstants.appName}", style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              const Text(
                "How will you be using the app?",
                style: TextStyle(color: Colors.black54, fontSize: 15),
              ),
              const SizedBox(height: 28),
              RoleCard(
                title: "I'm a Farmer",
                subtitle: "Post produce, find buyers, book a truck",
                icon: Icons.agriculture,
                onTap: () => _goToPhoneEntry(context, UserRole.farmer),
              ),
              const SizedBox(height: 12),
              RoleCard(
                title: "I'm a Buyer",
                subtitle: "Browse produce, order, pay, and track delivery",
                icon: Icons.storefront,
                onTap: () => _goToPhoneEntry(context, UserRole.buyer),
              ),
              const SizedBox(height: 12),
              RoleCard(
                title: "I'm a Truck Driver",
                subtitle: "Accept bookings and earn from deliveries",
                icon: Icons.local_shipping,
                onTap: () => _goToPhoneEntry(context, UserRole.driver),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _goToPhoneEntry(BuildContext context, UserRole role) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PhoneEntryScreen(role: role)),
    );
  }
}
