import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../utils/constants.dart';
import '../../widgets/big_button.dart';
import 'otp_verify_screen.dart';

class PhoneEntryScreen extends StatefulWidget {
  final UserRole role;
  const PhoneEntryScreen({super.key, required this.role});

  @override
  State<PhoneEntryScreen> createState() => _PhoneEntryScreenState();
}

class _PhoneEntryScreenState extends State<PhoneEntryScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  String? _fullPhone() {
    var digits = _phoneController.text.trim();
    if (digits.isEmpty) return null;
    // Accepts local Nigerian format (0803...) or already-international (+234...).
    if (digits.startsWith('0')) digits = digits.substring(1);
    if (!digits.startsWith('+')) digits = "+234$digits";
    return digits;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: Text("${widget.role.label} sign up")),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("What's your name?", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 8),
              TextField(
                controller: _nameController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(hintText: "e.g. Emmanuel Okafor"),
              ),
              const SizedBox(height: 20),
              const Text("Your phone number", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 8),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(hintText: "0803 123 4567"),
              ),
              const SizedBox(height: 8),
              const Text(
                "We'll send you a one-time code by SMS to confirm it's you.",
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
              if (auth.errorMessage != null) ...[
                const SizedBox(height: 16),
                Text(auth.errorMessage!, style: const TextStyle(color: Colors.red)),
              ],
              const Spacer(),
              BigButton(
                label: "Send Code",
                icon: Icons.sms_outlined,
                loading: auth.isLoading,
                onPressed: () async {
                  final phone = _fullPhone();
                  if (_nameController.text.trim().isEmpty || phone == null) return;
                  await auth.sendOtp(phone);
                  if (auth.errorMessage == null && auth.verificationId != null && context.mounted) {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => OtpVerifyScreen(
                          name: _nameController.text.trim(),
                          role: widget.role,
                        ),
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
