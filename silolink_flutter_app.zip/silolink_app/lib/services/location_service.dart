import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'firestore_service.dart';

class LocationService {
  final FirestoreService _firestoreService;
  Timer? _driverTimer;

  LocationService(this._firestoreService);

  /// Requests location permission if needed. Returns true if granted.
  Future<bool> ensurePermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return false;
    }
    if (permission == LocationPermission.deniedForever) return false;
    return true;
  }

  Future<Position?> getCurrentPosition() async {
    final granted = await ensurePermission();
    if (!granted) return null;
    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  double distanceKm(double lat1, double lng1, double lat2, double lng2) {
    return Geolocator.distanceBetween(lat1, lng1, lat2, lng2) / 1000.0;
  }

  /// Starts pushing this driver's location to Firestore every 10 seconds
  /// while they're online / on an active trip, per the spec's
  /// `driver_locations` collection requirement. Call [stopSharingLocation]
  /// when the driver goes offline or the trip ends — this timer runs
  /// indefinitely otherwise and will drain the phone's battery and data.
  void startSharingLocation(String driverId) {
    _driverTimer?.cancel();
    _driverTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      final pos = await getCurrentPosition();
      if (pos != null) {
        await _firestoreService.updateDriverLocation(driverId, pos.latitude, pos.longitude);
      }
    });
  }

  void stopSharingLocation() {
    _driverTimer?.cancel();
    _driverTimer = null;
  }
}
