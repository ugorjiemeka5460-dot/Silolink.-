import 'package:paystack_sdk_flutter/paystack_sdk_flutter.dart';

/// Wraps Paystack checkout for order payments.
///
/// ⚠️ VERIFY BEFORE SHIPPING: `paystack_sdk_flutter` (and Paystack's
/// various community Flutter wrappers) have shifted APIs between versions.
/// The method names below reflect the common "initialize with public key,
/// then charge" pattern used by most of these packages, but you should
/// cross-check them against the exact README of whatever version
/// `flutter pub get` resolves — I can't run this against a live package
/// registry from here to confirm the current method signatures.
class PaystackService {
  final PaystackSdkFlutter _paystack = PaystackSdkFlutter();
  bool _initialized = false;

  /// Call once at app startup (see main.dart) with your PUBLIC test key.
  /// Never put your SECRET key in the app — that belongs on a backend
  /// (e.g. a Cloud Function) that verifies the transaction server-side.
  Future<void> initialize(String publicKey) async {
    if (_initialized) return;
    await _paystack.initialize(publicKey: publicKey);
    _initialized = true;
  }

  /// Launches the Paystack payment sheet. Returns a reference string on
  /// success, or null if the user cancelled / payment failed.
  ///
  /// [amountNaira] is converted to kobo (Paystack's base unit) internally.
  Future<String?> chargeCard({
    required String email,
    required double amountNaira,
    required String reference,
  }) async {
    try {
      final response = await _paystack.checkout(
        email: email,
        amount: (amountNaira * 100).round(), // kobo
        reference: reference,
        currency: "NGN",
      );
      if (response.status == true) {
        return response.reference ?? reference;
      }
      return null;
    } catch (e) {
      // Surface a null result; the calling screen shows a friendly error.
      return null;
    }
  }
}
