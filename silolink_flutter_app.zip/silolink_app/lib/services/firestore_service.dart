import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../models/produce_model.dart';
import '../models/order_model.dart';
import '../models/booking_model.dart';
import '../utils/constants.dart';

/// Central place for every Firestore read/write in the app. Keeping all
/// queries here (rather than scattering .collection() calls through the
/// UI) means collection names and query shapes only need to change in one
/// place if the schema evolves.
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ---------- USERS ----------
  Future<void> createOrUpdateUser(AppUser user) {
    return _db.collection(AppConstants.usersCollection).doc(user.uid).set(
          user.toMap(),
          SetOptions(merge: true),
        );
  }

  Future<AppUser?> getUser(String uid) async {
    final doc = await _db.collection(AppConstants.usersCollection).doc(uid).get();
    if (!doc.exists) return null;
    return AppUser.fromMap(uid, doc.data()!);
  }

  Stream<AppUser?> streamUser(String uid) {
    return _db.collection(AppConstants.usersCollection).doc(uid).snapshots().map(
          (doc) => doc.exists ? AppUser.fromMap(uid, doc.data()!) : null,
        );
  }

  // ---------- PRODUCE ----------
  Future<String> addProduce(Produce produce) async {
    final ref = await _db.collection(AppConstants.produceCollection).add(produce.toMap());
    return ref.id;
  }

  Stream<List<Produce>> streamAvailableProduce({String? cropFilter}) {
    Query<Map<String, dynamic>> query = _db
        .collection(AppConstants.produceCollection)
        .where('status', isEqualTo: 'available')
        .orderBy('createdAt', descending: true);
    return query.snapshots().map((snap) {
      var items = snap.docs.map((d) => Produce.fromDoc(d)).toList();
      if (cropFilter != null && cropFilter.trim().isNotEmpty) {
        final q = cropFilter.toLowerCase();
        items = items.where((p) => p.crop.toLowerCase().contains(q)).toList();
      }
      return items;
    });
  }

  Stream<List<Produce>> streamFarmerProduce(String farmerId) {
    return _db
        .collection(AppConstants.produceCollection)
        .where('farmerId', isEqualTo: farmerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => Produce.fromDoc(d)).toList());
  }

  Future<void> markProduceSold(String produceId) {
    return _db.collection(AppConstants.produceCollection).doc(produceId).update({'status': 'sold'});
  }

  // ---------- ORDERS ----------
  Future<String> createOrder(OrderModel order) async {
    final ref = await _db.collection(AppConstants.ordersCollection).add(order.toMap());
    return ref.id;
  }

  Future<void> updateOrderStatus(String orderId, OrderStatus status, {String? paymentRef}) {
    final data = <String, dynamic>{'status': status.name};
    if (paymentRef != null) data['paymentRef'] = paymentRef;
    return _db.collection(AppConstants.ordersCollection).doc(orderId).update(data);
  }

  Stream<List<OrderModel>> streamBuyerOrders(String buyerId) {
    return _db
        .collection(AppConstants.ordersCollection)
        .where('buyerId', isEqualTo: buyerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => OrderModel.fromDoc(d)).toList());
  }

  Stream<List<OrderModel>> streamFarmerOrders(String farmerId) {
    return _db
        .collection(AppConstants.ordersCollection)
        .where('farmerId', isEqualTo: farmerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => OrderModel.fromDoc(d)).toList());
  }

  /// "Find Buyers" is powered by pending orders against the farmer's
  /// produce — a real "who viewed this" feature needs view-event logging,
  /// which isn't in scope yet. Pending orders are a reasonable proxy for
  /// "an interested buyer wants to talk."
  Stream<List<OrderModel>> streamPendingLeadsForFarmer(String farmerId) {
    return _db
        .collection(AppConstants.ordersCollection)
        .where('farmerId', isEqualTo: farmerId)
        .where('status', isEqualTo: OrderStatus.pending.name)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => OrderModel.fromDoc(d)).toList());
  }

  // ---------- BOOKINGS (truck logistics) ----------
  Future<String> createBooking(BookingModel booking) async {
    final ref = await _db.collection(AppConstants.bookingsCollection).add(booking.toMap());
    return ref.id;
  }

  Stream<List<BookingModel>> streamAvailableBookings() {
    return _db
        .collection(AppConstants.bookingsCollection)
        .where('status', isEqualTo: BookingStatus.requested.name)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  Stream<List<BookingModel>> streamDriverTrips(String driverId) {
    return _db
        .collection(AppConstants.bookingsCollection)
        .where('driverId', isEqualTo: driverId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  Stream<List<BookingModel>> streamRequesterBookings(String requesterId) {
    return _db
        .collection(AppConstants.bookingsCollection)
        .where('requesterId', isEqualTo: requesterId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  Stream<BookingModel?> streamBooking(String bookingId) {
    return _db.collection(AppConstants.bookingsCollection).doc(bookingId).snapshots().map(
          (doc) => doc.exists ? BookingModel.fromDoc(doc) : null,
        );
  }

  /// Uses a transaction so two drivers tapping "Accept" on the same
  /// booking at the same moment can't both win it.
  Future<bool> acceptBooking({
    required String bookingId,
    required String driverId,
    required String driverName,
  }) {
    final ref = _db.collection(AppConstants.bookingsCollection).doc(bookingId);
    return _db.runTransaction<bool>((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) return false;
      final currentStatus = snap.data()?['status'];
      if (currentStatus != BookingStatus.requested.name) return false; // already taken
      tx.update(ref, {
        'status': BookingStatus.accepted.name,
        'driverId': driverId,
        'driverName': driverName,
      });
      return true;
    });
  }

  Future<void> updateBookingStatus(String bookingId, BookingStatus status) {
    return _db.collection(AppConstants.bookingsCollection).doc(bookingId).update({'status': status.name});
  }

  // ---------- DRIVER LIVE LOCATION ----------
  Future<void> updateDriverLocation(String driverId, double lat, double lng) {
    return _db.collection(AppConstants.driverLocationsCollection).doc(driverId).set({
      'lat': lat,
      'lng': lng,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> streamDriverLocation(String driverId) {
    return _db.collection(AppConstants.driverLocationsCollection).doc(driverId).snapshots();
  }
}
