import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import '../utils/constants.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadProducePhoto(File file, String farmerId) async {
    final fileName = "${const Uuid().v4()}.jpg";
    final ref = _storage.ref().child("${AppConstants.producePhotosPath}/$farmerId/$fileName");
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }
}
