import 'package:firebase_auth/firebase_auth.dart';

/// Thin wrapper around FirebaseAuth's phone OTP flow.
///
/// NOTE ON FREE-TIER LIMITS: Phone Auth works on Firebase's free Spark
/// plan, but Google enforces a small daily SMS quota on Spark and requires
/// Play Integrity / SafetyNet (Android) or APNs (iOS) device attestation to
/// skip reCAPTCHA. For anything beyond testing with a handful of real
/// numbers, budget for upgrading to the pay-as-you-go Blaze plan — it still
/// has a free monthly allowance, you only pay past it.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  /// Starts the phone verification flow. [onCodeSent] receives the
  /// verificationId needed to confirm the OTP. [onAutoVerified] fires on
  /// Android devices that can auto-read the SMS without user input.
  Future<void> sendOtp({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(String error) onError,
    required void Function(UserCredential credential) onAutoVerified,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        final result = await _auth.signInWithCredential(credential);
        onAutoVerified(result);
      },
      verificationFailed: (FirebaseAuthException e) {
        onError(e.message ?? "Verification failed. Please try again.");
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        // No-op: we already have the verificationId from codeSent.
      },
    );
  }

  Future<UserCredential> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return _auth.signInWithCredential(credential);
  }

  Future<void> signOut() => _auth.signOut();
}
