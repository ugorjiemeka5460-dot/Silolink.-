import 'package:flutter/foundation.dart';
import '../models/order_model.dart';
import '../models/produce_model.dart';
import '../services/firestore_service.dart';
import '../services/paystack_service.dart';
import '../utils/constants.dart';

class OrderProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  final PaystackService paystackService = PaystackService();

  bool isProcessing = false;
  String? errorMessage;

  Stream<List<OrderModel>> buyerOrders(String buyerId) => _firestoreService.streamBuyerOrders(buyerId);
  Stream<List<OrderModel>> farmerOrders(String farmerId) => _firestoreService.streamFarmerOrders(farmerId);
  Stream<List<OrderModel>> farmerLeads(String farmerId) => _firestoreService.streamPendingLeadsForFarmer(farmerId);

  Future<String?> placeOrder({
    required Produce produce,
    required String buyerId,
    required String buyerName,
    required double quantity,
  }) async {
    isProcessing = true;
    notifyListeners();
    final order = OrderModel(
      id: '',
      buyerId: buyerId,
      buyerName: buyerName,
      farmerId: produce.farmerId,
      farmerName: produce.farmerName,
      produceId: produce.id,
      crop: produce.crop,
      quantity: quantity,
      totalPrice: quantity * produce.pricePerKg,
    );
    final id = await _firestoreService.createOrder(order);
    isProcessing = false;
    notifyListeners();
    return id;
  }

  /// Opens the Paystack sheet and, on success, marks the order paid and
  /// the produce sold. Takes primitives rather than a full OrderModel
  /// since callers typically only have the freshly-created orderId at
  /// this point.
  Future<bool> payForOrder({
    required String orderId,
    required String produceId,
    required String buyerEmail,
    required double totalPrice,
  }) async {
    isProcessing = true;
    notifyListeners();

    final reference = "silolink_${orderId}_${DateTime.now().millisecondsSinceEpoch}";
    final result = await paystackService.chargeCard(
      email: buyerEmail,
      amountNaira: totalPrice,
      reference: reference,
    );

    if (result != null) {
      await _firestoreService.updateOrderStatus(orderId, OrderStatus.paid, paymentRef: result);
      await _firestoreService.markProduceSold(produceId);
      isProcessing = false;
      notifyListeners();
      return true;
    }

    errorMessage = "Payment was not completed.";
    isProcessing = false;
    notifyListeners();
    return false;
  }
}
