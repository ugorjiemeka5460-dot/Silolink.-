import 'package:flutter/foundation.dart';
import '../models/booking_model.dart';
import '../services/firestore_service.dart';
import '../services/location_service.dart';
import '../utils/constants.dart';

class BookingProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  late final LocationService locationService;

  bool isSubmitting = false;
  String? errorMessage;

  BookingProvider() {
    locationService = LocationService(_firestoreService);
  }

  double distanceKm(double lat1, double lng1, double lat2, double lng2) =>
      locationService.distanceKm(lat1, lng1, lat2, lng2);

  double quoteFor(String truckSize, double distanceKm) {
    switch (truckSize) {
      case 'Medium':
        return AppConstants.truckBaseFareMedium + (AppConstants.perKmRateMedium * distanceKm);
      case 'Large':
        return AppConstants.truckBaseFareLarge + (AppConstants.perKmRateLarge * distanceKm);
      case 'Small':
      default:
        return AppConstants.truckBaseFareSmall + (AppConstants.perKmRateSmall * distanceKm);
    }
  }

  Future<String?> createBooking(BookingModel booking) async {
    isSubmitting = true;
    notifyListeners();
    try {
      final id = await _firestoreService.createBooking(booking);
      isSubmitting = false;
      notifyListeners();
      return id;
    } catch (e) {
      errorMessage = "Couldn't book a truck: $e";
      isSubmitting = false;
      notifyListeners();
      return null;
    }
  }

  Stream<List<BookingModel>> availableBookings() => _firestoreService.streamAvailableBookings();
  Stream<List<BookingModel>> driverTrips(String driverId) => _firestoreService.streamDriverTrips(driverId);
  Stream<List<BookingModel>> requesterBookings(String requesterId) => _firestoreService.streamRequesterBookings(requesterId);
  Stream<BookingModel?> watchBooking(String bookingId) => _firestoreService.streamBooking(bookingId);
  Stream driverLocationStream(String driverId) => _firestoreService.streamDriverLocation(driverId);

  Future<bool> acceptBooking(String bookingId, String driverId, String driverName) {
    return _firestoreService.acceptBooking(bookingId: bookingId, driverId: driverId, driverName: driverName);
  }

  Future<void> updateStatus(String bookingId, BookingStatus status) {
    return _firestoreService.updateBookingStatus(bookingId, status);
  }

  void goOnline(String driverId) {
    locationService.startSharingLocation(driverId);
    notifyListeners();
  }

  void goOffline() {
    locationService.stopSharingLocation();
    notifyListeners();
  }
}
