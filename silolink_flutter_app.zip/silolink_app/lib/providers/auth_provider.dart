import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../utils/constants.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final FirestoreService _firestoreService = FirestoreService();

  AppUser? currentAppUser;
  User? firebaseUser;
  String? verificationId;
  bool isLoading = false;
  String? errorMessage;

  AuthProvider() {
    _authService.authStateChanges.listen((user) async {
      firebaseUser = user;
      if (user != null) {
        currentAppUser = await _firestoreService.getUser(user.uid);
      } else {
        currentAppUser = null;
      }
      notifyListeners();
    });
  }

  bool get isLoggedIn => firebaseUser != null;
  bool get hasProfile => currentAppUser != null;

  Future<void> sendOtp(String phoneNumber) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    await _authService.sendOtp(
      phoneNumber: phoneNumber,
      onCodeSent: (id) {
        verificationId = id;
        isLoading = false;
        notifyListeners();
      },
      onError: (msg) {
        errorMessage = msg;
        isLoading = false;
        notifyListeners();
      },
      onAutoVerified: (credential) {
        isLoading = false;
        notifyListeners();
      },
    );
  }

  /// Verifies the OTP, then creates the user's Firestore profile if this
  /// is their first time signing in.
  Future<bool> verifyOtpAndCreateProfile({
    required String smsCode,
    required String name,
    required UserRole role,
  }) async {
    if (verificationId == null) {
      errorMessage = "Please request a code first.";
      notifyListeners();
      return false;
    }
    isLoading = true;
    notifyListeners();

    try {
      final result = await _authService.verifyOtp(
        verificationId: verificationId!,
        smsCode: smsCode,
      );
      final uid = result.user!.uid;
      final phone = result.user!.phoneNumber ?? "";

      final existing = await _firestoreService.getUser(uid);
      if (existing == null) {
        final newUser = AppUser(uid: uid, name: name, phone: phone, role: role);
        await _firestoreService.createOrUpdateUser(newUser);
        currentAppUser = newUser;
      } else {
        currentAppUser = existing;
      }
      isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message ?? "Invalid code. Please try again.";
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> refreshProfile() async {
    if (firebaseUser == null) return;
    currentAppUser = await _firestoreService.getUser(firebaseUser!.uid);
    notifyListeners();
  }

  Future<void> signOut() async {
    await _authService.signOut();
    currentAppUser = null;
    firebaseUser = null;
    notifyListeners();
  }
}
