import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/produce_model.dart';
import '../services/firestore_service.dart';
import '../services/storage_service.dart';

class ProduceProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  final StorageService _storageService = StorageService();

  bool isSubmitting = false;
  String? errorMessage;

  Stream<List<Produce>> browseAvailable({String? cropFilter}) {
    return _firestoreService.streamAvailableProduce(cropFilter: cropFilter);
  }

  Stream<List<Produce>> myProduce(String farmerId) {
    return _firestoreService.streamFarmerProduce(farmerId);
  }

  Future<bool> postProduce({
    required String farmerId,
    required String farmerName,
    required String farmerPhone,
    required String crop,
    required double quantity,
    required double pricePerKg,
    File? photo,
    double? lat,
    double? lng,
    required String locationName,
  }) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();

    try {
      String? photoUrl;
      if (photo != null) {
        photoUrl = await _storageService.uploadProducePhoto(photo, farmerId);
      }
      final produce = Produce(
        id: '',
        farmerId: farmerId,
        farmerName: farmerName,
        farmerPhone: farmerPhone,
        crop: crop,
        quantity: quantity,
        pricePerKg: pricePerKg,
        photoUrl: photoUrl,
        lat: lat,
        lng: lng,
        locationName: locationName,
      );
      await _firestoreService.addProduce(produce);
      isSubmitting = false;
      notifyListeners();
      return true;
    } catch (e) {
      errorMessage = "Couldn't post produce: $e";
      isSubmitting = false;
      notifyListeners();
      return false;
    }
  }
}
