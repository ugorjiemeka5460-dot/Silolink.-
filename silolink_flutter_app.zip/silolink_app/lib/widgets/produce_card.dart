import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';
import '../models/produce_model.dart';

class ProduceCard extends StatelessWidget {
  final Produce produce;
  final VoidCallback onTap;

  const ProduceCard({super.key, required this.produce, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final currency = NumberFormat.currency(locale: 'en_NG', symbol: '₦', decimalDigits: 0);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 96,
              height: 96,
              child: produce.photoUrl != null
                  ? CachedNetworkImage(
                      imageUrl: produce.photoUrl!,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(color: const Color(0xFFEFEFEF)),
                      errorWidget: (_, __, ___) => const Icon(Icons.agriculture, size: 40),
                    )
                  : Container(
                      color: const Color(0xFFE8F5E9),
                      child: const Icon(Icons.agriculture, size: 40, color: Color(0xFF2E7D32)),
                    ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(produce.crop, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text(
                      "${produce.quantity.toStringAsFixed(0)} kg available",
                      style: const TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.location_on, size: 14, color: Colors.black45),
                        const SizedBox(width: 2),
                        Expanded(
                          child: Text(
                            produce.locationName,
                            style: const TextStyle(color: Colors.black45, fontSize: 12),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "${currency.format(produce.pricePerKg)}/kg",
                      style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF2E7D32), fontSize: 15),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
