import 'package:flutter/material.dart';
import '../utils/theme.dart';

class StatusPill extends StatelessWidget {
  final String label;
  final Color color;

  const StatusPill({super.key, required this.label, required this.color});

  factory StatusPill.forOrderStatus(String status) {
    switch (status) {
      case 'paid':
        return StatusPill(label: "Paid", color: AppTheme.primaryGreen);
      case 'confirmed':
        return const StatusPill(label: "Confirmed", color: Color(0xFF1565C0));
      case 'delivered':
        return StatusPill(label: "Delivered", color: AppTheme.primaryGreen);
      case 'cancelled':
        return StatusPill(label: "Cancelled", color: AppTheme.dangerRed);
      case 'pending':
      default:
        return const StatusPill(label: "Pending Payment", color: Color(0xFFEF6C00));
    }
  }

  factory StatusPill.forBookingStatus(String status) {
    switch (status) {
      case 'accepted':
        return const StatusPill(label: "Accepted", color: Color(0xFF1565C0));
      case 'inTransit':
        return StatusPill(label: "In Transit", color: AppTheme.accentYellow);
      case 'delivered':
        return StatusPill(label: "Delivered", color: AppTheme.primaryGreen);
      case 'cancelled':
        return StatusPill(label: "Cancelled", color: AppTheme.dangerRed);
      case 'requested':
      default:
        return const StatusPill(label: "Requested", color: Color(0xFF6A1B9A));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(20)),
      child: Text(
        label,
        style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}
