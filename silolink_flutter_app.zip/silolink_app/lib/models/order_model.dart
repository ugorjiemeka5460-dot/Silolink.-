import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';

class OrderModel {
  final String id;
  final String buyerId;
  final String buyerName;
  final String farmerId;
  final String farmerName;
  final String produceId;
  final String crop;
  final double quantity;
  final double totalPrice;
  final OrderStatus status;
  final String? paymentRef;
  final DateTime? createdAt;

  OrderModel({
    required this.id,
    required this.buyerId,
    required this.buyerName,
    required this.farmerId,
    required this.farmerName,
    required this.produceId,
    required this.crop,
    required this.quantity,
    required this.totalPrice,
    this.status = OrderStatus.pending,
    this.paymentRef,
    this.createdAt,
  });

  factory OrderModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final map = doc.data()!;
    return OrderModel(
      id: doc.id,
      buyerId: map['buyerId'] ?? '',
      buyerName: map['buyerName'] ?? '',
      farmerId: map['farmerId'] ?? '',
      farmerName: map['farmerName'] ?? '',
      produceId: map['produceId'] ?? '',
      crop: map['crop'] ?? '',
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0,
      totalPrice: (map['totalPrice'] as num?)?.toDouble() ?? 0,
      status: OrderStatusX.fromString(map['status'] ?? 'pending'),
      paymentRef: map['paymentRef'],
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'buyerId': buyerId,
      'buyerName': buyerName,
      'farmerId': farmerId,
      'farmerName': farmerName,
      'produceId': produceId,
      'crop': crop,
      'quantity': quantity,
      'totalPrice': totalPrice,
      'status': status.name,
      'paymentRef': paymentRef,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }
}
