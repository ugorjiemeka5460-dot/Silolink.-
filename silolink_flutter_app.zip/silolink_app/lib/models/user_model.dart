import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';

class AppUser {
  final String uid;
  final String name;
  final String phone;
  final UserRole role;
  final double? lat;
  final double? lng;
  final String? locationName;
  final bool isOnline; // relevant for drivers
  final double walletBalance;
  final DateTime? createdAt;

  AppUser({
    required this.uid,
    required this.name,
    required this.phone,
    required this.role,
    this.lat,
    this.lng,
    this.locationName,
    this.isOnline = false,
    this.walletBalance = 0,
    this.createdAt,
  });

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      role: UserRoleX.fromString(map['role'] ?? 'buyer'),
      lat: (map['lat'] as num?)?.toDouble(),
      lng: (map['lng'] as num?)?.toDouble(),
      locationName: map['locationName'],
      isOnline: map['isOnline'] ?? false,
      walletBalance: (map['walletBalance'] as num?)?.toDouble() ?? 0,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'role': role.name,
      'lat': lat,
      'lng': lng,
      'locationName': locationName,
      'isOnline': isOnline,
      'walletBalance': walletBalance,
      'createdAt': createdAt == null ? FieldValue.serverTimestamp() : Timestamp.fromDate(createdAt!),
    };
  }

  AppUser copyWith({
    String? name,
    double? lat,
    double? lng,
    String? locationName,
    bool? isOnline,
    double? walletBalance,
  }) {
    return AppUser(
      uid: uid,
      name: name ?? this.name,
      phone: phone,
      role: role,
      lat: lat ?? this.lat,
      lng: lng ?? this.lng,
      locationName: locationName ?? this.locationName,
      isOnline: isOnline ?? this.isOnline,
      walletBalance: walletBalance ?? this.walletBalance,
      createdAt: createdAt,
    );
  }
}
