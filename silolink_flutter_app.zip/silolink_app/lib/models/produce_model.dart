import 'package:cloud_firestore/cloud_firestore.dart';

class Produce {
  final String id;
  final String farmerId;
  final String farmerName;
  final String farmerPhone;
  final String crop;
  final double quantity; // in kg
  final double pricePerKg;
  final String? photoUrl;
  final double? lat;
  final double? lng;
  final String locationName;
  final String status; // 'available' | 'sold'
  final DateTime? createdAt;

  Produce({
    required this.id,
    required this.farmerId,
    required this.farmerName,
    required this.farmerPhone,
    required this.crop,
    required this.quantity,
    required this.pricePerKg,
    this.photoUrl,
    this.lat,
    this.lng,
    required this.locationName,
    this.status = 'available',
    this.createdAt,
  });

  double get totalValue => quantity * pricePerKg;

  factory Produce.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final map = doc.data()!;
    return Produce(
      id: doc.id,
      farmerId: map['farmerId'] ?? '',
      farmerName: map['farmerName'] ?? '',
      farmerPhone: map['farmerPhone'] ?? '',
      crop: map['crop'] ?? '',
      quantity: (map['quantity'] as num?)?.toDouble() ?? 0,
      pricePerKg: (map['pricePerKg'] as num?)?.toDouble() ?? 0,
      photoUrl: map['photoUrl'],
      lat: (map['lat'] as num?)?.toDouble(),
      lng: (map['lng'] as num?)?.toDouble(),
      locationName: map['locationName'] ?? '',
      status: map['status'] ?? 'available',
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'farmerId': farmerId,
      'farmerName': farmerName,
      'farmerPhone': farmerPhone,
      'crop': crop,
      'quantity': quantity,
      'pricePerKg': pricePerKg,
      'photoUrl': photoUrl,
      'lat': lat,
      'lng': lng,
      'locationName': locationName,
      'status': status,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }
}
