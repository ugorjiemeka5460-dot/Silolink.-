import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';

class BookingModel {
  final String id;
  final String requesterId; // farmer or buyer who requested the truck
  final String requesterName;
  final String? driverId;
  final String? driverName;
  final String truckSize; // 'Small' | 'Medium' | 'Large'
  final double pickupLat;
  final double pickupLng;
  final String pickupAddress;
  final double dropoffLat;
  final double dropoffLng;
  final String dropoffAddress;
  final double distanceKm;
  final double price;
  final BookingStatus status;
  final DateTime? createdAt;

  BookingModel({
    required this.id,
    required this.requesterId,
    required this.requesterName,
    this.driverId,
    this.driverName,
    required this.truckSize,
    required this.pickupLat,
    required this.pickupLng,
    required this.pickupAddress,
    required this.dropoffLat,
    required this.dropoffLng,
    required this.dropoffAddress,
    required this.distanceKm,
    required this.price,
    this.status = BookingStatus.requested,
    this.createdAt,
  });

  factory BookingModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final map = doc.data()!;
    return BookingModel(
      id: doc.id,
      requesterId: map['requesterId'] ?? '',
      requesterName: map['requesterName'] ?? '',
      driverId: map['driverId'],
      driverName: map['driverName'],
      truckSize: map['truckSize'] ?? 'Small',
      pickupLat: (map['pickupLat'] as num?)?.toDouble() ?? 0,
      pickupLng: (map['pickupLng'] as num?)?.toDouble() ?? 0,
      pickupAddress: map['pickupAddress'] ?? '',
      dropoffLat: (map['dropoffLat'] as num?)?.toDouble() ?? 0,
      dropoffLng: (map['dropoffLng'] as num?)?.toDouble() ?? 0,
      dropoffAddress: map['dropoffAddress'] ?? '',
      distanceKm: (map['distanceKm'] as num?)?.toDouble() ?? 0,
      price: (map['price'] as num?)?.toDouble() ?? 0,
      status: BookingStatusX.fromString(map['status'] ?? 'requested'),
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'requesterId': requesterId,
      'requesterName': requesterName,
      'driverId': driverId,
      'driverName': driverName,
      'truckSize': truckSize,
      'pickupLat': pickupLat,
      'pickupLng': pickupLng,
      'pickupAddress': pickupAddress,
      'dropoffLat': dropoffLat,
      'dropoffLng': dropoffLng,
      'dropoffAddress': dropoffAddress,
      'distanceKm': distanceKm,
      'price': price,
      'status': status.name,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }
}
