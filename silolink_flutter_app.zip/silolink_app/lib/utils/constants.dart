/// App-wide constants: collection names, pricing config, and shared strings.
/// Centralizing these avoids typos in Firestore collection names scattered
/// across the codebase.
library;

class AppConstants {
  AppConstants._();

  static const String appName = "SiloLink";
  static const String tagline = "From Farm to Market in 24 Hours";

  // Firestore collection names
  static const String usersCollection = "users";
  static const String produceCollection = "produce";
  static const String ordersCollection = "orders";
  static const String bookingsCollection = "bookings";
  static const String driverLocationsCollection = "driver_locations";

  // Storage paths
  static const String producePhotosPath = "produce_photos";

  // Logistics pricing (naira). Real pricing should come from a remote
  // config / admin panel eventually — these are starter defaults.
  static const double truckBaseFareSmall = 3000;
  static const double truckBaseFareMedium = 5500;
  static const double truckBaseFareLarge = 9000;
  static const double perKmRateSmall = 150;
  static const double perKmRateMedium = 220;
  static const double perKmRateLarge = 320;

  // Default map center (Lagos, Nigeria) used before we get the user's
  // real location.
  static const double defaultLat = 6.5244;
  static const double defaultLng = 3.3792;
}

enum UserRole { farmer, buyer, driver }

extension UserRoleX on UserRole {
  String get label {
    switch (this) {
      case UserRole.farmer:
        return "Farmer";
      case UserRole.buyer:
        return "Buyer";
      case UserRole.driver:
        return "Truck Driver";
    }
  }

  static UserRole fromString(String value) {
    return UserRole.values.firstWhere(
      (r) => r.name == value,
      orElse: () => UserRole.buyer,
    );
  }
}

enum OrderStatus { pending, paid, confirmed, delivered, cancelled }

extension OrderStatusX on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.pending:
        return "Pending Payment";
      case OrderStatus.paid:
        return "Paid";
      case OrderStatus.confirmed:
        return "Confirmed";
      case OrderStatus.delivered:
        return "Delivered";
      case OrderStatus.cancelled:
        return "Cancelled";
    }
  }

  static OrderStatus fromString(String value) {
    return OrderStatus.values.firstWhere(
      (s) => s.name == value,
      orElse: () => OrderStatus.pending,
    );
  }
}

enum BookingStatus { requested, accepted, inTransit, delivered, cancelled }

extension BookingStatusX on BookingStatus {
  String get label {
    switch (this) {
      case BookingStatus.requested:
        return "Requested";
      case BookingStatus.accepted:
        return "Accepted";
      case BookingStatus.inTransit:
        return "In Transit";
      case BookingStatus.delivered:
        return "Delivered";
      case BookingStatus.cancelled:
        return "Cancelled";
    }
  }

  static BookingStatus fromString(String value) {
    return BookingStatus.values.firstWhere(
      (s) => s.name == value,
      orElse: () => BookingStatus.requested,
    );
  }
}
